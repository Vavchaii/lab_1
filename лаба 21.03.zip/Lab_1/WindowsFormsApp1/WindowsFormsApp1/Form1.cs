﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // ImgList
        Country[] countries = new Country[5];
        String[] imglist = new String[]
            {"1.jpg","2.jpg","3.jpg","4.jpg","5.jpg"};
        int index = 0;
        public Form1()
        {
            InitializeComponent();

            pictureBox2.Load("../../../picture/" + imglist[0]);
            pictureBox3.Load("../../../picture/" + imglist[1]);
            pictureBox4.Load("../../../picture/" + imglist[2]);
            //pictureBox1.Load("../Lab_1/../picture/" + imglist[3]);
            //pictureBox1.Load("../Lab_1/../picture/" + imglist[4]);
            Country country = new Country();
            country.set("", "");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Visitors = new Visitor_menu();
            Visitors.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form Admin = new FormAdmin();
            Admin.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
