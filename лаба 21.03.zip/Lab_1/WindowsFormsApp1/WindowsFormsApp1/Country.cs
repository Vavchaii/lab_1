﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Country
    {
        String countryCode;
        String countryName;


        public void set(String countryCode, String countryName)
        { this.countryCode = countryCode;
          this.countryName = countryName;}
    }
}
