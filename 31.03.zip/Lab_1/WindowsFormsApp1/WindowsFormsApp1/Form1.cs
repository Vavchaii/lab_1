﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        // ImgList
        Country[] countries = new Country[5];
        Player[] players = new Player[5];
        String[] imglist = new String[]
            {"1.jpg","2.jpg","3.jpg","4.jpg","5.jpg","6.jpg","7.jpg","8.jpg","9.jpg"};
        int index = 0;
        public Form1()
        {
            InitializeComponent();

            pictureBox2.Load("../../../picture/" + imglist[0]);
            pictureBox3.Load("../../../picture/" + imglist[1]);
            pictureBox4.Load("../../../picture/" + imglist[2]);
            
            Country country = new Country();

            // 5 элементов
            country.set("ARG", "Argentina");
            countries[0] = country;

            country.set("AT", "Austria");
            countries[1] = country;

            country.set("AUS", "Australia");
            countries[2] = country;

            country.set("BI", "Bosnia");
            countries[3] = country;

            country.set("BR", "Brazil");
            countries[4] = country;


            Player player = new Player();
            // 5 элементов
            player.set("1","Barkley", "Ross", "Male","196","112","18","Australia","Miami Heat", "Small Forward;Center");
            players[0] = player;

            player.set("2", "Dembl", "Moussa", "Male", "172", "99", "47", "Argentina", "Orlando Magic", "Power Forward");
            players[1] = player;

            player.set("3", "Alaba", "David", "Male", "193", "122", "17", "Austia", "Atlanta Hawks", "Center");
            players[2] = player;

            player.set("4", "Hummels", "Mats", "Male", "173", "145", "34", "Australia", "Washington Wizards", "ShootingGuard");
            players[3] = player;

            player.set("5", "Soares", "Cdric", "Male", "176", "162", "79", "Bosnia", "Charlotte Hornets", "Point Guard");
            players[4] = player;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Visitors = new Visitor_menu();
            Visitors.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form Admin = new FormAdmin();
            Admin.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            index = index +1;
            if (index +3 > imglist.Length) index = 0;
            pictureBox2.Load("../../../picture/" + imglist[index +0]);
            pictureBox3.Load("../../../picture/" + imglist[index +1]);
            pictureBox4.Load("../../../picture/" + imglist[index +2]);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            index = index - 1;
            if (index < 0 ) index = imglist.Length - 3;
            pictureBox2.Load("../../../picture/" + imglist[index + 0]);
            pictureBox3.Load("../../../picture/" + imglist[index + 1]);
            pictureBox4.Load("../../../picture/" + imglist[index + 2]);
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
