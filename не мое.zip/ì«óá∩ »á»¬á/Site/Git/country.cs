﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Git
{
    internal class country
    {
        String countryCode;
        String countryName;


        public void setCountryCode(string countryCode)
        {
            this.countryCode = countryCode;
        }
        public void setCountryName(string countryName)
        {
            this.countryName = countryName;
        }
    }
}
