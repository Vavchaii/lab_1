﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Git
{
    public partial class Team_Detail : Form
    {
        public Team_Detail()
        {
            InitializeComponent();
        }

        private void Team_Detail_Load(object sender, EventArgs e)
        {

        }

       
        

        

    
    }
}
