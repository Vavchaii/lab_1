﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        String[] imgList = new String[]
            {"1.jpg","2.jpg","3.jpg","4.jpg","5.jpg","6.jpg","7.jpg","8.jpg","9.jpg",};
        int index=0;
        public Form1()
        {
            InitializeComponent();
            pictureBox2.Load("../../../picture/" + imgList[0]);
            pictureBox3.Load("../../../picture/" + imgList[1]);
            pictureBox4.Load("../../../picture/" + imgList[2]);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form Visitors = new Form2();
            Visitors.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
