﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Team_Menu : Form
    {
        Teams[] team = new Teams[5];
        public Team_Menu()
        {
            InitializeComponent();
            Teams teams = new Teams();
            // 5 элементов
            teams.set("1", "Toronto Raptors", "TOR", "");
            team[0] = teams;

            teams.set("2", "Los Angeles Lakers", "LAL", "");
            team[1] = teams;

            teams.set("3", "Golden State Warriors", "GSW", "");
            team[2] = teams;

            teams.set("4", "Chicago Bulls", "CB", "");
            team[3] = teams;

            teams.set("5", "Brooklyn Nets", "BN", "");
            team[4] = teams;

            label3.Text = team[0].teamsName;
        }

        private void button1_Click(object sender, EventArgs e)
        {
         this.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
