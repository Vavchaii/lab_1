﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class Teams
    {
        string TeamID;
        public string Name;
        string Abbr;
        string Logo;


        String teamsCode;
        public String teamsName;

        
        public void set(String teamCode,String teamName)
        { this.teamsCode = teamCode; 
            this.teamsName = teamName; }
        }
    }

