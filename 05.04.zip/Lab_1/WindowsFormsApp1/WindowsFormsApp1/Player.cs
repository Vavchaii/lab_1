﻿using System;

namespace WindowsFormsApp1
{
    internal class Player
    {
        internal void set(string v1, string v2, string v3, string v4, string v5, string v6, string v7, string v8, string v9, string v10)
        {
          //  throw new NotImplementedException();
        }
    }
}